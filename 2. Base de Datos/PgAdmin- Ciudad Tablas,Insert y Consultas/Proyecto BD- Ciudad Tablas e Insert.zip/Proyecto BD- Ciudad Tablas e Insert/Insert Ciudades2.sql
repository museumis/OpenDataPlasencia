﻿/*CIUDAD 1 - PLASENCIA*/

/*--------------------------*/

INSERT INTO CIUDAD
	VALUES(1,'Plasencia','España', 'http://www.plasencia.es','https://www.google.es/maps/place/Plasencia',40663,'2017-7-31','2017-8-2','10600')
	;

SELECT *
FROM CIUDAD

/*--------------------------*/

INSERT INTO GOBIERNO
	VALUES(1,1,'Fernando Pizarro García','Alcaldia','2015-5-24',null,1),
	(2,1,'Luis Díaz Sánchez','Juventud','2015-5-24',null,1),
	(3,1,'Fernando Pizarro','Educación','2015-5-24',null,1),
	(4,1,'David Dóniga Estévez','Innovación','2015-5-24',null,1),	
	(5,1,'Mª Luisa Bermejo','Cultura','2015-5-24',null,1)
	;

SELECT *
FROM GOBIERNO


/*--------------------------*/

INSERT INTO ORGANISMO
VALUES(1,1,'Parque Comarcal de bomberos de Plasencia','Polígono Industrial. C/ Juan de la Cierva  s/n','080/927 410 080/927 427 063','Seguridad'),
(2,1,'Jefatura de la Policía Local','Avenida de las Acacias, s/n (La Mazuela)','092/927 42 13 15/927 42 65 64','Seguridad'),
(3,1,'C.C.E.I.P.S San Calixto','Av. Virgen del Puerto','927 41 13 47','Educación'),
(4,1,'C.E.I.P. Miralvalle','Calle Cayetano García Martín','927 01 78 00','Educación'),
(5,1,'Colegio Público El Pilar','Av. Extremadura','927 41 13 47','Educación'),
(6,1,'C.E.I.P. Alfonso VIII','Calle Cristo de las Batallas','927 01 77 96','Educación'),
(7,1,'CEIP Inés Suárez','Parque de la Coronación','927 01 77 84','Educación'),
(8,1,'IES Valle del Jerte','Calle Pedro y Francisco González','927 01 77 74','Educación'),
(9,1,'I.E.S. Gabriel y Galán','España, Av. Cañada Real','927 01 77 88','Educación'),
(10,1,'Instituto Pérez Comendador','Av. Virgen del Puerto','927 01 77 32','Educación'),
(11,1,'I.E.S. Sierra de Santa Bárbara','Calle Aldehuela del Jerte','927 42 46 26','Educación'),
(12,1,'Centro Universitario De Plasencia','Av. Virgen del Puerto','927 42 77 00','Educación'),
(13,1,'U.N.E.D. Plasencia','Plaza Sta. Ana','927 42 05 20','Educación'),
(14,1,'Hospital Virgen del puerto','Paraje Valcorchero','927 42 83 00','Sanidad'),
(15,1,'Luis de Toro','Calle Luis de Toro','CitaPrevia:927 423 436/Urgencias:927 423 380','Sanidad'),
(16,1,'San Miguel','Calle Antonio Vargas y Laguna','Urgencias: 927 407 522','Sanidad'),
(17,1,'La Data','Calle Cañada Real','CitaPrevia:927 428 421/Urgencias:927 428 420','Sanidad'),
(18,1,'Salud Mental','Avda.de la Salle','927 458 036','Sanidad'),
(19,1,'Conductas Adictivas','Avda.de la Salle','927 458 036','Sanidad')


INSERT INTO ORGANISMO
VALUES()

SELECT *
FROM ORGANISMO

DELETE FROM ORGANISMO

/*--------------------------*/
/*Cod_claseorg / Cod_Organismo / tipo Institución*/

INSERT INTO CLASEORGANISMO
VALUES(1,8,'Instituto'),
(2,9,'Instituto'),
(3,10,'Instituto'),
(4,11,'Instituto'),
(5,12,'Universidad'),
(6,13,'Universidad'),
(7,14,'Hospital'),
(8,15,'Centro de Salud'),
(9,16,'Centro de Salud'),
(10,17,'Centro de Salud'),
(11,18,'Centro de Salud'),
(12,19,'Centro de Salud')

INSERT INTO CLASEORGANISMO
VALUES()

SELECT *
FROM CLASEORGANISMO

DELETE FROM CLASEORGANISMO

/*--------------------------*/

INSERT INTO INSTITUTO
VALUES(1,1),
(2,2),
(3,3),
(4,4)

SELECT *
FROM INSTITUTO

DELETE FROM INSTITUTO

/*--------------------------*/

INSERT INTO DEPARTAMENTO
VALUES(1,1,'Informática y Comunicaciones',100),
(2,1,'Tecnología',50),
(3,1,'Inglés',50),
(4,1,'Música',50),
(1,2,'Filosofía',50),
(2,2,'Física y Química',50),
(3,2,'Economía',50),
(4,2,'Peluquería',50),
(1,3,'Proyecto de Edificación y obra Civil',50),
(2,3,'Inglés',30),
(3,3,'Música',30),
(1,4,'Inglés',30),
(2,4,'Música',30)


SELECT * 
FROM DEPARTAMENTO

DELETE FROM DEPARTAMENTO

SELECT *
FROM DEPARTAMENTO
WHERE COD_INSTITUTO = 1;

SELECT *
FROM ((ORGANISMO INNER JOIN CLASEORGANISMO ON ORGANISMO.COD_ORGANISMO=CLASEORGANISMO.COD_ORGANISMO)
INNER JOIN INSTITUTO ON INSTITUTO.COD_CLASEORG = CLASEORGANISMO.COD_CLASEORG)
INNER JOIN DEPARTAMENTO ON INSTITUTO.COD_INSTITUTO = DEPARTAMENTO.COD_INSTITUTO
WHERE DEPARTAMENTO.NOMBRE = 'Informática y Comunicaciones';

/*--------------------------*/

INSERT INTO UNIVERSIDAD
VALUES(1,5),
(2,6)

SELECT *
FROM UNIVERSIDAD

DELETE FROM UNIVERSIDAD

/*--------------------------*/


INSERT INTO CARRERA
VALUES(1,1,'Grado en Administración y Dirección de Empresas',200),
(2,1,'Grado en Enfermería',100),
(3,1,'Grado en Ingeniería Forestal y del Medio Natural',150),
(4,1,'Grado en Podología',150),

(1,2,'Filosofía',200),
(2,2,'Historia',200),
(3,2,'Ciencias Físicas',150),
(4,2,'Derecho',150)

SELECT * 
FROM CARRERA


SELECT *
FROM CARRERA
WHERE COD_UNIVERSIDAD=1;

SELECT *
FROM ((ORGANISMO INNER JOIN CLASEORGANISMO ON ORGANISMO.COD_ORGANISMO=CLASEORGANISMO.COD_ORGANISMO)
INNER JOIN UNIVERSIDAD ON UNIVERSIDAD.COD_CLASEORG = CLASEORGANISMO.COD_CLASEORG)
INNER JOIN CARRERA ON UNIVERSIDAD.COD_UNIVERSIDAD = CARRERA.COD_UNIVERSIDAD
WHERE CARRERA.NOMBRE = 'Filosofía';

/*--------------------------*/
INSERT INTO HOSPITAL
VALUES(1,7,250)

SELECT *
FROM HOSPITAL

DELETE FROM HOSPITAL


/*--------------------------*/
INSERT INTO CENTRO_SALUD
VALUES(1,8),
(2,9),
(3,10),
(4,11),
(5,12)

SELECT *
FROM CENTRO_SALUD

/*--------------------------*/

INSERT INTO BARRIO
VALUES(1,1,'Rosal de Ayala',1),
(2,1,'Miralvalle',3),
(3,1,'El Pilar',3),
(4,1,'San Miguel',2),
(5,1,'La Data',2)

DELETE FROM BARRIO

SELECT *
FROM BARRIO

SELECT *
FROM BARRIO
WHERE CENTRO_SALUD = '3'

SELECT *
FROM CENTRO_SALUD INNER JOIN BARRIO ON CENTRO_SALUD.COD_CENTROSALUD=BARRIO.CENTRO_SALUD
WHERE BARRIO.NOMBRE = 'Rosal de Ayala'

SELECT *
FROM ((ORGANISMO INNER JOIN CLASEORGANISMO ON ORGANISMO.COD_ORGANISMO=CLASEORGANISMO.COD_ORGANISMO)
INNER JOIN CENTRO_SALUD ON CENTRO_SALUD.COD_CLASEORG = CLASEORGANISMO.COD_CLASEORG)
INNER JOIN BARRIO ON CENTRO_SALUD.COD_CENTROSALUD=BARRIO.CENTRO_SALUD
WHERE BARRIO.NOMBRE = 'Rosal de Ayala'


/*--------------------------*/

INSERT INTO ASOCIACION_VECINO
VALUES(1,1,'Rosal de Ayala','C/ Enrique de Egas','927 42 64 56/651 96 12 29'),
(2,2,'Asociación de Vecinos de Miralvalle','Calle Enrique de Egas','927 41 08 99/686 06 66 57'),
(3,3,'El pilar-plaza de toros','pilarplasezadetoros@hotmail.com','927424100 / 674183125'),
(4,5,'La Data','C/ Cañada Real','927 41 59 10')

SELECT *
FROM ASOCIACION_VECINO




















*


