
/*CIUDAD 1 - PLASENCIA*/

/*--------------------------*/

INSERT INTO CIUDAD
	VALUES(1,'Plasencia','Espa�a', 'http://www.plasencia.es','https://www.google.es/maps/place/Plasencia',40663,'2017-7-31','2017-8-2','10600')
	;

SELECT *
FROM CIUDAD

/*--------------------------*/

INSERT INTO GOBIERNO
	VALUES(1,1,'Fernando Pizarro Garc�a','Alcaldia','2015-5-24',null,1),
	(2,1,'Luis D�az S�nchez','Juventud','2015-5-24',null,1),
	(3,1,'Fernando Pizarro','Educaci�n','2015-5-24',null,1),
	(4,1,'David D�niga Est�vez','Innovaci�n','2015-5-24',null,1),	
	(5,1,'M� Luisa Bermejo','Cultura','2015-5-24',null,1)
	;

SELECT *
FROM GOBIERNO


/*--------------------------*/

INSERT INTO ORGANISMO
VALUES(1,1,'Parque Comarcal de bomberos de Plasencia','Pol�gono Industrial. C/ Juan de la Cierva  s/n','080/927 410 080/927 427 063','Seguridad'),
(2,1,'Jefatura de la Polic�a Local','Avenida de las Acacias, s/n (La Mazuela)','092/927 42 13 15/927 42 65 64','Seguridad'),
(3,1,'C.C.E.I.P.S San Calixto','Av. Virgen del Puerto','927 41 13 47','Educaci�n'),
(4,1,'C.E.I.P. Miralvalle','Calle Cayetano Garc�a Mart�n','927 01 78 00','Educaci�n'),
(5,1,'Colegio P�blico El Pilar','Av. Extremadura','927 41 13 47','Educaci�n'),
(6,1,'C.E.I.P. Alfonso VIII','Calle Cristo de las Batallas','927 01 77 96','Educaci�n'),
(7,1,'CEIP In�s Su�rez','Parque de la Coronaci�n','927 01 77 84','Educaci�n'),
(8,1,'IES Valle del Jerte','Calle Pedro y Francisco Gonz�lez','927 01 77 74','Educaci�n'),
(9,1,'I.E.S. Gabriel y Gal�n','Espa�a, Av. Ca�ada Real','927 01 77 88','Educaci�n'),
(10,1,'Instituto P�rez Comendador','Av. Virgen del Puerto','927 01 77 32','Educaci�n'),
(11,1,'I.E.S. Sierra de Santa B�rbara','Calle Aldehuela del Jerte','927 42 46 26','Educaci�n'),
(12,1,'Centro Universitario De Plasencia','Av. Virgen del Puerto','927 42 77 00','Educaci�n'),
(13,1,'U.N.E.D. Plasencia','Plaza Sta. Ana','927 42 05 20','Educaci�n'),
(14,1,'Hospital Virgen del puerto','Paraje Valcorchero','927 42 83 00','Sanidad'),
(15,1,'Luis de Toro','Calle Luis de Toro','CitaPrevia:927 423 436/Urgencias:927 423 380','Sanidad'),
(16,1,'San Miguel','Calle Antonio Vargas y Laguna','Urgencias: 927 407 522','Sanidad'),
(17,1,'La Data','Calle Ca�ada Real','CitaPrevia:927 428 421/Urgencias:927 428 420','Sanidad'),
(18,1,'Salud Mental','Avda.de la Salle','927 458 036','Sanidad'),
(19,1,'Conductas Adictivas','Avda.de la Salle','927 458 036','Sanidad')


INSERT INTO ORGANISMO
VALUES()

SELECT *
FROM ORGANISMO

DELETE FROM ORGANISMO

/*--------------------------*/
/*Cod_claseorg / Cod_Organismo / tipo Instituci�n*/

INSERT INTO CLASEORGANISMO
VALUES(1,8,'Instituto'),
(2,9,'Instituto'),
(3,10,'Instituto'),
(4,11,'Instituto'),
(5,12,'Universidad'),
(6,13,'Universidad'),
(7,14,'Hospital'),
(8,15,'Centro de Salud'),
(9,16,'Centro de Salud'),
(10,17,'Centro de Salud'),
(11,18,'Centro de Salud'),
(12,19,'Centro de Salud')

INSERT INTO CLASEORGANISMO
VALUES()

SELECT *
FROM CLASEORGANISMO

DELETE FROM CLASEORGANISMO

/*--------------------------*/

INSERT INTO INSTITUTO
VALUES(1,1),
(2,2),
(3,3),
(4,4)

SELECT *
FROM INSTITUTO

DELETE FROM INSTITUTO

/*--------------------------*/

INSERT INTO DEPARTAMENTO
VALUES(1,1,'Inform�tica y Comunicaciones',100),
(2,1,'Tecnolog�a',50),
(3,1,'Ingl�s',50),
(4,1,'M�sica',50),
(1,2,'Filosof�a',50),
(2,2,'F�sica y Qu�mica',50),
(3,2,'Econom�a',50),
(4,2,'Peluquer�a',50),
(1,3,'Proyecto de Edificaci�n y obra Civil',50),
(2,3,'Ingl�s',30),
(3,3,'M�sica',30),
(1,4,'Ingl�s',30),
(2,4,'M�sica',30)


SELECT * 
FROM DEPARTAMENTO

DELETE FROM DEPARTAMENTO

SELECT *
FROM DEPARTAMENTO
WHERE COD_INSTITUTO = 1;

SELECT *
FROM ((ORGANISMO INNER JOIN CLASEORGANISMO ON ORGANISMO.COD_ORGANISMO=CLASEORGANISMO.COD_ORGANISMO)
INNER JOIN INSTITUTO ON INSTITUTO.COD_CLASEORG = CLASEORGANISMO.COD_CLASEORG)
INNER JOIN DEPARTAMENTO ON INSTITUTO.COD_INSTITUTO = DEPARTAMENTO.COD_INSTITUTO
WHERE DEPARTAMENTO.NOMBRE = 'Inform�tica y Comunicaciones';

/*--------------------------*/

INSERT INTO UNIVERSIDAD
VALUES(1,5),
(2,6)

SELECT *
FROM UNIVERSIDAD

DELETE FROM UNIVERSIDAD

/*--------------------------*/


INSERT INTO CARRERA
VALUES(1,1,'Grado en Administraci�n y Direcci�n de Empresas',200),
(2,1,'Grado en Enfermer�a',100),
(3,1,'Grado en Ingenier�a Forestal y del Medio Natural',150),
(4,1,'Grado en Podolog�a',150),

(1,2,'Filosof�a',200),
(2,2,'Historia',200),
(3,2,'Ciencias F�sicas',150),
(4,2,'Derecho',150)

SELECT * 
FROM CARRERA


SELECT *
FROM CARRERA
WHERE COD_UNIVERSIDAD=1;

SELECT *
FROM ((ORGANISMO INNER JOIN CLASEORGANISMO ON ORGANISMO.COD_ORGANISMO=CLASEORGANISMO.COD_ORGANISMO)
INNER JOIN UNIVERSIDAD ON UNIVERSIDAD.COD_CLASEORG = CLASEORGANISMO.COD_CLASEORG)
INNER JOIN CARRERA ON UNIVERSIDAD.COD_UNIVERSIDAD = CARRERA.COD_UNIVERSIDAD
WHERE CARRERA.NOMBRE = 'Filosof�a';

/*--------------------------*/
INSERT INTO HOSPITAL
VALUES(1,7,250)

SELECT *
FROM HOSPITAL

DELETE FROM HOSPITAL


/*--------------------------*/
INSERT INTO CENTRO_SALUD
VALUES(1,8),
(2,9),
(3,10),
(4,11),
(5,12)

SELECT *
FROM CENTRO_SALUD

/*--------------------------*/

INSERT INTO BARRIO
VALUES(1,1,'Rosal de Ayala',1),
(2,1,'Miralvalle',3),
(3,1,'El Pilar',3),
(4,1,'San Miguel',2),
(5,1,'La Data',2)

DELETE FROM BARRIO

SELECT *
FROM BARRIO

SELECT *
FROM BARRIO
WHERE CENTRO_SALUD = '3'

SELECT *
FROM CENTRO_SALUD INNER JOIN BARRIO ON CENTRO_SALUD.COD_CENTROSALUD=BARRIO.CENTRO_SALUD
WHERE BARRIO.NOMBRE = 'Rosal de Ayala'

SELECT *
FROM ((ORGANISMO INNER JOIN CLASEORGANISMO ON ORGANISMO.COD_ORGANISMO=CLASEORGANISMO.COD_ORGANISMO)
INNER JOIN CENTRO_SALUD ON CENTRO_SALUD.COD_CLASEORG = CLASEORGANISMO.COD_CLASEORG)
INNER JOIN BARRIO ON CENTRO_SALUD.COD_CENTROSALUD=BARRIO.CENTRO_SALUD
WHERE BARRIO.NOMBRE = 'Rosal de Ayala'


/*--------------------------*/

INSERT INTO ASOCIACION_VECINO
VALUES(1,1,'Rosal de Ayala','C/ Enrique de Egas','927 42 64 56/651 96 12 29'),
(2,2,'Asociaci�n de Vecinos de Miralvalle','Calle Enrique de Egas','927 41 08 99/686 06 66 57'),
(3,3,'El pilar-plaza de toros','pilarplasezadetoros@hotmail.com','927424100 / 674183125'),
(4,5,'La Data','C/ Ca�ada Real','927 41 59 10')

SELECT *
FROM ASOCIACION_VECINO


