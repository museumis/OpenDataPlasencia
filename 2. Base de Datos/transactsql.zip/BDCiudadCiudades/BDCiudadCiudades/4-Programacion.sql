
/*1 - Comprueba si el hospital tiene m�s de 300 camas.*/
DECLARE @NUMEROCAMAS INT;
SET @NUMEROCAMAS = (SELECT NUMERO_CAMAS FROM
(ORGANISMO INNER JOIN CLASEORGANISMO ON ORGANISMO.COD_ORGANISMO=CLASEORGANISMO.COD_ORGANISMO)
INNER JOIN HOSPITAL ON HOSPITAL.COD_CLASEORG = CLASEORGANISMO.COD_CLASEORG)
IF(@NUMEROCAMAS>300)
BEGIN
PRINT'-El numero de camas en mayor que 300'
END
ELSE
BEGIN
PRINT'-El numero de camas en menor que 300'
END


/*2 - Haz un procedimiento que actualice el n�mero de camas disponibles en el hospital.*/

ALTER PROCEDURE actualizarCamas @camas int
AS
UPDATE HOSPITAL SET NUMERO_CAMAS = @camas;

EXEC actualizarCamas '250'

/*3 - La consulta anterior con try/Cath.*/

ALTER PROCEDURE actualizarCamas @camas int
AS
BEGIN TRY
BEGIN TRAN
UPDATE HOSPITAL SET NUMERO_CAMAS = @camas;
COMMIT
END TRY
BEGIN CATCH
ROLLBACK
PRINT 'Error -> ' + ERROR_MESSAGE()
END CATCH

SELECT NUMERO_CAMAS FROM HOSPITAL

/*4 - Crea un procedimiento que retoner el n�mero de camas, introduciendo el n�mero de plantas.*/

CREATE PROCEDURE camasPorPlanta @camasPorPlanta DECIMAL(10,2) OUTPUT, @plantas INT
AS
BEGIN TRY
BEGIN TRAN
SET @camasPorPlanta = (SELECT NUMERO_CAMAS FROM HOSPITAL)/@plantas
COMMIT
END TRY
BEGIN CATCH
ROLLBACK
PRINT 'Error -> ' + ERROR.MESSAGE()
END CATCH


DECLARE @camasPorPlanta DECIMAL(10,2) 
EXEC camasPorPlanta @camasPorPlanta output,'5'
select @camasPorPlanta AS NumeroDeCamasPorPlanta

/* 5 - Crea una funcion que cuente los organismos de la ciudad*/
CREATE FUNCTION numeroOrg()
RETURNS INT
AS
BEGIN
DECLARE @total INT
SET @total =
(SELECT COUNT(COD_ORGANISMO) 
FROM ORGANISMO
WHERE TIPO ='Educaci�n'
GROUP BY TIPO)
 + 
(SELECT COUNT(COD_ORGANISMO) 
FROM ORGANISMO
WHERE TIPO ='Sanidad'
GROUP BY TIPO)
 + 
(SELECT COUNT(COD_ORGANISMO) 
FROM ORGANISMO
WHERE TIPO ='Seguridad'
GROUP BY TIPO) 
RETURN @total
END

SELECT DBO.numeroOrg() AS Organismos

/*6 - Crea un triger para impedir que se pueda actualizar la tabla ciudad*/

ALTER TRIGGER noUpdateCiudad
on Ciudad
FOR UPDATE
AS
PRINT'NO SE PUEDE ACTUALIZAR LA TABLA CIUDAD.'
ROLLBACK TRANSACTION

UPDATE CIUDAD SET PAIS = 'NoSeActualiza'

SELECT * FROM CIUDAD

DISABLE TRIGGER noUpdateCiudad ON CIUDAD

ENABLE TRIGGER noUpdateCiudad ON CIUDAD